#include <iostream>
#include "LinkedList.h"
using namespace std;

int main()
{
    LinkedList * List = new LinkedList();

    List->add(10);


    //List->Display();

    if(List->Search(35))
        cout<<"found";
    else cout<<"Not found";


    bool deleted = List->Delete(10);

    cout<<deleted;


}
